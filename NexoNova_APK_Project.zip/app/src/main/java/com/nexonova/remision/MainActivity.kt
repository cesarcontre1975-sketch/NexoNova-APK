package com.nexonova.remision

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AppBridge(), "AndroidBridge")
        if (savedInstanceState != null) webView.restoreState(savedInstanceState) else webView.loadUrl("file:///android_asset/index.html")
    }
    override fun onSaveInstanceState(outState: Bundle) { webView.saveState(outState); super.onSaveInstanceState(outState) }
    override fun onBackPressed() { if (webView.canGoBack()) webView.goBack() else super.onBackPressed() }
    inner class AppBridge {
        @JavascriptInterface fun printPdf() { runOnUiThread {
            val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
            pm.print("NexoNova Nota de Remisión", webView.createPrintDocumentAdapter("NexoNova-Nota"), PrintAttributes.Builder().build())
        } }
        @JavascriptInterface fun shareWhatsApp(message: String) { runOnUiThread {
            try { startActivity(Intent(Intent.ACTION_SEND).apply { type="text/plain"; setPackage("com.whatsapp"); putExtra(Intent.EXTRA_TEXT,message) }) }
            catch (_: Exception) { try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,message) }, "Compartir nota")) } catch (_: Exception) { Toast.makeText(this@MainActivity,"No se pudo abrir compartir",Toast.LENGTH_LONG).show() } }
        } }
        @JavascriptInterface fun copyText(message: String) { runOnUiThread {
            val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cb.setPrimaryClip(ClipData.newPlainText("Resumen NexoNova",message))
            Toast.makeText(this@MainActivity,"Resumen copiado",Toast.LENGTH_SHORT).show()
        } }
    }
}
